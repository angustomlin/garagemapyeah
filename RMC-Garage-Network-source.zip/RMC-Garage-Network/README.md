# RMC Garage Network

Full source for the garage finder app. Extract this ZIP and push the contents of the RMC-Garage-Network folder into your Git repository.

## Stack
React, TypeScript, Vinext, Cloudflare Workers and D1 (SQLite). This is a full-stack application, not a single static HTML page. GitHub Pages alone cannot run its API or database.

## Run locally
Requires Node.js 22.13 or newer and pnpm.

```sh
pnpm install --frozen-lockfile
pnpm run build
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_elite_dreaming_celestial.sql
pnpm run dev
```

## Push to a new empty Git repository
Run inside the extracted project folder, replacing YOUR_REPOSITORY_URL:

```sh
git init
git add .
git commit -m "Initial garage network app"
git branch -M main
git remote add origin YOUR_REPOSITORY_URL
git push -u origin main
```

## Configuration and deployment
The included .openai/hosting.json identifies the existing ChatGPT Site and its DB binding. Keep it when maintaining that Site. For a different host, configure a Cloudflare Worker and D1 database and apply the included migration; the existing Sites private-access gate does not transfer to another host. Add authentication before exposing garage records on another host.

Set GOOGLE_PLACES_API_KEY as a server-side secret to enable live Google Places results. Enable Places API (New) and billing in the Google project. Without that secret, the app offers Google Maps search links.

Postcode lookup uses api.postcodes.io. The map uses Leaflet with CARTO tiles. Network access to these services is required.

## Verification and limitations
Production build and distance-calculation checks passed. Live postcode lookup and garage-save flows were not verified end to end in the preview. Distances are straight-line estimates. Google alternatives are not trusted automatically.

No credentials, node_modules, build output, local database or Git history are included. Database records are not part of this source export.
