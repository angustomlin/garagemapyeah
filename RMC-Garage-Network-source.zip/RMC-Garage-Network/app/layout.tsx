import type {Metadata} from 'next';import './globals.css';
export const metadata:Metadata={title:'Garage Network | RMC',description:'The right garage. Wherever your customer is.'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
