CREATE TABLE `garages` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`postcode` text NOT NULL,
	`lat` real NOT NULL,
	`lng` real NOT NULL,
	`specialists` text DEFAULT '' NOT NULL,
	`phone` text DEFAULT '' NOT NULL,
	`contact` text DEFAULT '' NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`status` text DEFAULT 'trusted' NOT NULL
);
